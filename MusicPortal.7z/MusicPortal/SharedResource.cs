﻿namespace MusicPortal
{
    public class SharedResource
    {
    }
}
